import { test, expect, Locator } from "@playwright/test"

test("Registration form ", async ({ page }) => {

   await page.goto("https://app.playonereal.com/agent-signup")
   const fname: Locator = page.locator("[name='firstName']")
   //expect(fname).toBeVisible()
   await fname.fill("Naveen")
   const lname: Locator = page.locator("[name='lastName']")
   //expect(lname).toBeVisible()
   await lname.fill("Patil")
   page.waitForTimeout(2000)
   const Username: Locator = page.locator("[name='username']")
   //(Username).toBeVisible()
   await Username.fill("vardhamanpatil")

   const email: Locator = page.locator("[name='emailAddress']")

   await email.fill("vardhamanpatil@gmail.com")
   const password: Locator = page.locator("[name='password']")
   await password.fill("Vardhu@#123rtyi")
   const pwdConfirm: Locator = page.locator("[name='confirmPassword']")
   await pwdConfirm.fill("Vardhu@#123rtyi")
   const fcheckbox: Locator = page.locator("#mantine-3gwp8zhhv")
   expect(fcheckbox).toBeVisible();
   await fcheckbox.check()
   expect(fcheckbox).toBeChecked()
   const scheckbox: Locator = page.locator("#mantine-31s5e791y")
   await scheckbox.check()
   expect(scheckbox).toBeChecked()
   const acctClick: Locator = page.getByText("Create Account")
   await acctClick.click()

})
